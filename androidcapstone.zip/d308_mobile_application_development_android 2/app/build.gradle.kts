plugins {
    id("com.android.application")
    kotlin("android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.brandenvw.vacationmanager"          // <- your code namespace
    compileSdk = 34

    defaultConfig {
        applicationId = "com.brandenvw.vacationmanager"  // <- NOT com.example.*
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.1"

        // Room (optional)
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
            arg("room.incremental", "true")
            arg("room.expandProjection", "true")
        }
    }

    // ---- define signing BEFORE buildTypes ----
    val hasSigningProps = listOf("STORE_FILE","STORE_PASSWORD","KEY_ALIAS","KEY_PASSWORD")
        .all { project.findProperty(it) != null }

    signingConfigs {
        if (hasSigningProps) {
            create("release") {
                storeFile = file(project.property("STORE_FILE") as String)
                storePassword = project.property("STORE_PASSWORD") as String
                keyAlias = project.property("KEY_ALIAS") as String
                keyPassword = project.property("KEY_PASSWORD") as String
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasSigningProps) {
                signingConfig = signingConfigs.getByName("release")
            } // else you can still build unsigned; Studio’s wizard can sign for you
        }
        debug {
            // applicationIdSuffix = ".debug" // optional
        }
    }
    // ------------------------------------------

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { viewBinding = true }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    // Read from gradle.properties if set, else fall back to 2.6.1
    val roomVersion = (project.findProperty("ROOM_VERSION") as String?) ?: "2.6.1"

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.fragment:fragment-ktx:1.8.3")

    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}

