package com.example.brandenvw;

import static org.junit.Assert.*;

import android.content.Context;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.brandenvw.vacationmanager.dao.ExcursionDao;
import com.brandenvw.vacationmanager.dao.VacationDao;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
// CHANGE THIS IMPORT TO MATCH YOUR REAL DB PACKAGE/CLASS:
import com.brandenvw.vacationmanager.database.AppDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class ExcursionDaoTest {

    @Rule public InstantTaskExecutorRule instantRule = new InstantTaskExecutorRule();

    private AppDatabase db;

    @Before
    public void createDb() {
        Context ctx = ApplicationProvider.getApplicationContext();
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase.class)
                .allowMainThreadQueries()
                .build();
    }

    @After
    public void closeDb() throws IOException {
        db.close();
    }

    @Test
    public void insertQueryUpdateDelete_Excursion_CRUD() throws Exception {
        VacationDao vacationDao =
                db.vacationDao();
        ExcursionDao excursionDao =
                db.excursionDao();

        // Insert a Vacation (foreign key owner)
        Vacation v = new Vacation("Hawaii", "Hilton", 2000.00, "2025-07-10", "2025-07-20");
        long vid = vacationDao.insert(v);
        assertTrue(vid > 0);

        // Insert two excursions
        Excursion e1 = new Excursion("Snorkeling", 75.00, (int) vid, "2025-07-12", "Reef tour");
        Excursion e2 = new Excursion("Hike", 0.00, (int) vid, "2025-07-14", "Sunrise trail");
        long e1Id = excursionDao.insert(e1);
        long e2Id = excursionDao.insert(e2);
        assertTrue(e1Id > 0);
        assertTrue(e2Id > 0);

        // Query by vacation
        List<Excursion> list = LiveDataTestUtil.getOrAwaitValue(
                excursionDao.getForVacation((int) vid)
        );
        assertEquals(2, list.size());
        assertEquals((int) vid, list.get(0).getVacationId());

        // Update first
        Excursion first = list.get(0);
        first.setNotes("Updated note");
        int rows = excursionDao.update(first);
        assertTrue(rows > 0);

        // Verify getById
        Excursion byId = LiveDataTestUtil.getOrAwaitValue(
                excursionDao.getById(first.getExcursionId())
        );
        assertEquals("Updated note", byId.getNotes());

        // Delete all and verify empty
        excursionDao.deleteAll();
        List<Excursion> afterDeleteAll = LiveDataTestUtil.getOrAwaitValue(excursionDao.getAll());
        assertTrue(afterDeleteAll.isEmpty());
    }
}
