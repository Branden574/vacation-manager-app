package com.example.brandenvw;

import static java.util.concurrent.TimeUnit.SECONDS;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public final class LiveDataTestUtil {
    private LiveDataTestUtil() {}

    public static <T> T getOrAwaitValue(LiveData<T> liveData) throws InterruptedException {
        return getOrAwaitValue(liveData, 5, SECONDS);
    }

    public static <T> T getOrAwaitValue(LiveData<T> liveData, long time, TimeUnit unit) throws InterruptedException {
        final AtomicReference<T> data = new AtomicReference<>();
        final CountDownLatch latch = new CountDownLatch(1);

        final Observer<T> observer = value -> {
            data.set(value);
            latch.countDown();
        };

        liveData.observeForever(observer);
        try {
            if (!latch.await(time, unit)) {
                throw new AssertionError("LiveData value was never set within timeout");
            }
        } finally {
            liveData.removeObserver(observer);
        }
        return data.get();
    }
}
