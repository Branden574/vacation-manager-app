package com.example.brandenvw;

import static org.junit.Assert.*;

import android.content.Context;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.brandenvw.vacationmanager.dao.VacationDao;
import com.brandenvw.vacationmanager.entities.Vacation;
// CHANGE THIS IMPORT TO MATCH YOUR REAL DB PACKAGE/CLASS:
import com.brandenvw.vacationmanager.database.AppDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class VacationDaoTest {

    @Rule public InstantTaskExecutorRule instantRule = new InstantTaskExecutorRule();

    private AppDatabase db;

    @Before
    public void createDb() {
        Context ctx = ApplicationProvider.getApplicationContext();
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase.class)
                .allowMainThreadQueries()
                .build();
    }

    @After
    public void closeDb() throws IOException {
        db.close();
    }

    @Test
    public void insertQueryUpdateDelete_Vacation_CRUD() throws Exception {
        // If your accessor is named vacationDAO(), change it here
        VacationDao vacationDao =
                db.vacationDao();

        Vacation v = new Vacation("Bermuda Trip", "Beach Resort", 1234.56, "2025-08-01", "2025-08-10");
        long id = vacationDao.insert(v);
        assertTrue(id > 0);

        List<Vacation> all = LiveDataTestUtil.getOrAwaitValue(vacationDao.getAll());
        assertEquals(1, all.size());
        Vacation got = all.get(0);
        assertEquals("Bermuda Trip", got.getTitle());
        assertEquals("Beach Resort", got.getHotel());

        got.setHotel("Ocean View");
        int rows = vacationDao.update(got);
        assertTrue(rows > 0);

        Vacation byId = LiveDataTestUtil.getOrAwaitValue(vacationDao.getById(got.getVacationID()));
        assertEquals("Ocean View", byId.getHotel());

        int del = vacationDao.delete(byId);
        assertTrue(del > 0);

        List<Vacation> afterDelete = LiveDataTestUtil.getOrAwaitValue(vacationDao.getAll());
        assertTrue(afterDelete.isEmpty());
    }
}
