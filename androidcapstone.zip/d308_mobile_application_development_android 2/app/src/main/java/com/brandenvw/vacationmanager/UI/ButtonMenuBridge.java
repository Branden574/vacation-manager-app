package com.brandenvw.vacationmanager.UI;

import android.view.Menu;
import android.view.View;
import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

/** Forwards button clicks to an existing options-menu handler by ID. */
public final class ButtonMenuBridge {

    private ButtonMenuBridge() {}

    public static void wire(AppCompatActivity activity,
                            @IdRes int toolbarId,
                            @IdRes int saveButtonId, @IdRes int saveMenuItemId,
                            @IdRes int deleteButtonId, @IdRes int deleteMenuItemId) {
        MaterialToolbar toolbar = activity.findViewById(toolbarId);
        activity.setSupportActionBar(toolbar);    // shows the activity's menu

        View saveBtn = activity.findViewById(saveButtonId);
        if (saveBtn != null) {
            saveBtn.setOnClickListener(v -> {
                Menu m = toolbar.getMenu();
                m.performIdentifierAction(saveMenuItemId, 0);
            });
        }
        View delBtn = activity.findViewById(deleteButtonId);
        if (delBtn != null) {
            delBtn.setOnClickListener(v -> {
                Menu m = toolbar.getMenu();
                m.performIdentifierAction(deleteMenuItemId, 0);
            });
        }

        // Forward toolbar item clicks into your Activity's onOptionsItemSelected
        toolbar.setOnMenuItemClickListener(item -> activity.onOptionsItemSelected(item));
    }
}
