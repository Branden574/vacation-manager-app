package com.brandenvw.vacationmanager.UI;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.brandenvw.vacationmanager.R;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.repositories.Repository;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;

public class ExcursionDetails extends AppCompatActivity {

    private TextInputEditText etTitle;
    private TextInputEditText etPrice;
    private TextInputEditText etDate;
    private TextInputEditText etNotes;

    private MaterialButton btnSave;

    private Repository repository;
    private int vacationId = -1;
    private int excursionId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excursion_details);

        repository = new Repository(getApplication());

        // Toolbar + back (Up) arrow
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Excursion Details");
        }
        if (toolbar != null) {
            // ❗ Java needs the getter:
            toolbar.setNavigationOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());
        }

        etTitle = findViewById(R.id.etExcursionTitle);
        etPrice = findViewById(R.id.etExcursionPrice);
        etDate  = findViewById(R.id.etExcursionDate);
        etNotes = findViewById(R.id.etExcursionNotes);
        btnSave = findViewById(R.id.btnSaveExcursion);

        // Date picker
        etDate.setOnClickListener(v -> showDatePicker(etDate));

        // Intent extras
        if (getIntent() != null) {
            vacationId = getIntent().getIntExtra("vacationId", -1);
            excursionId = getIntent().getIntExtra("excursionId", -1);
        }

        // Load existing excursion
        if (excursionId != -1) {
            repository.getExcursionById(excursionId).observe(this, e -> {
                if (e == null) return;
                etTitle.setText(nz(e.getTitle()));
                etPrice.setText(String.valueOf(e.getPrice()));
                etDate.setText(nz(e.getDate()));
                etNotes.setText(nz(e.getNotes()));
            });
        }

        btnSave.setOnClickListener(v -> saveExcursion());
    }

    @Override
    public boolean onSupportNavigateUp() {
        // ❗ Java needs the getter:
        getOnBackPressedDispatcher().onBackPressed();
        return true;
    }

    private void showDatePicker(TextInputEditText target) {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String m = String.format(Locale.US, "%02d", month + 1);
                    String d = String.format(Locale.US, "%02d", dayOfMonth);
                    target.setText(year + "-" + m + "-" + d);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    private void saveExcursion() {
        String title = s(etTitle);
        String priceStr = s(etPrice);
        String date = s(etDate);
        String notes = s(etNotes);

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date) || vacationId == -1) {
            Toast.makeText(this, "Title, Date, and a valid Vacation are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = 0.0;
        try { if (!TextUtils.isEmpty(priceStr)) price = Double.parseDouble(priceStr); }
        catch (NumberFormatException ignored) {}

        Excursion e = new Excursion(
                excursionId == -1 ? 0 : excursionId,
                title, price, vacationId, date, notes
        );

        if (excursionId == -1) {
            repository.insert(e);
            Toast.makeText(this, "Excursion created", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            repository.update(e);
            Toast.makeText(this, "Excursion updated", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /* ===== toolbar menu: Save / Delete / Share ===== */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_excursion_details, menu);
        if (excursionId == -1) {
            MenuItem del = menu.findItem(R.id.action_delete_excursion);
            if (del != null) del.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_save_excursion) {
            saveExcursion();
            return true;
        }
        if (id == R.id.action_delete_excursion) {
            if (excursionId == -1) return true;
            Excursion e = new Excursion(excursionId, "", 0.0, vacationId, "", "");
            repository.delete(e);
            Toast.makeText(this, "Excursion deleted", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        }
        if (id == R.id.action_share_excursion) {
            shareExcursion();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void shareExcursion() {
        String title = s(etTitle);
        String priceStr = s(etPrice);
        String date = s(etDate);
        String notes = s(etNotes);

        NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
        String pricePretty;
        try {
            double p = TextUtils.isEmpty(priceStr) ? 0.0 : Double.parseDouble(priceStr);
            pricePretty = nf.format(p);
        } catch (NumberFormatException e) {
            pricePretty = priceStr;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Excursion Details\n");
        sb.append("-----------------\n");
        sb.append("Title: ").append(TextUtils.isEmpty(title) ? "(none)" : title).append("\n");
        sb.append("Date: ").append(TextUtils.isEmpty(date) ? "(none)" : date).append("\n");
        sb.append("Price: ").append(TextUtils.isEmpty(pricePretty) ? "(none)" : pricePretty).append("\n");
        sb.append("Notes: ").append(TextUtils.isEmpty(notes) ? "(none)" : notes).append("\n");

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "Excursion Details");
        share.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(share, "Share via"));
    }

    private static String s(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
