package com.brandenvw.vacationmanager.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.brandenvw.vacationmanager.R;            // <-- add this
import com.brandenvw.vacationmanager.util.SessionManager;


public class Login extends AppCompatActivity {

    private EditText editEmail, editPassword;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(getApplicationContext());
        if (session.isLoggedIn()) {
            startActivity(new Intent(this, VacationList.class));
            finish();
            return;
        }

        editEmail    = findViewById(resolveId("editEmail","email","inputEmail","etEmail","textEmail"));
        editPassword = findViewById(resolveId("editPassword","password","inputPassword","etPassword","textPassword"));
        Button btnLogin = findViewById(resolveId("btnLogin","buttonLogin","signIn","buttonSignIn"));

        if (editEmail != null && session.getEmail() != null) {
            editEmail.setText(session.getEmail());
        }

        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String email = editEmail != null ? editEmail.getText().toString().trim() : "";
        String pass  = editPassword != null ? editPassword.getText().toString() : "";

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
            Toast.makeText(this, "Enter email and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!session.hasSavedCredentials()) {
            int userId = Math.abs(email.hashCode());
            session.saveCredentials(userId, email, pass);
            session.setLoggedIn(true);
            Toast.makeText(this, "Account created & signed in.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, VacationList.class));
            finish();
            return;
        }

        if (session.verifyLogin(email, pass)) {
            Toast.makeText(this, "Signed in.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, VacationList.class));
            finish();
        } else {
            Toast.makeText(this, "Incorrect email or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private int resolveId(String... names) {
        for (String n : names) {
            int id = getResources().getIdentifier(n, "id", getPackageName());
            if (id != 0) return id;
        }
        return 0;
    }
}
