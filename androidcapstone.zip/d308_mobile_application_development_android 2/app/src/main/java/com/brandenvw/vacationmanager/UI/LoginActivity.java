package com.brandenvw.vacationmanager.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.brandenvw.vacationmanager.R;
import com.brandenvw.vacationmanager.util.SessionManager;
import com.brandenvw.vacationmanager.util.AuthManager; // ✅ added import

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);

        editTextEmail       = findViewById(R.id.editTextEmail);
        editTextPassword    = findViewById(R.id.editTextPassword);
        buttonLogin         = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create Account
        buttonCreateAccount.setOnClickListener(v -> {
            String email = s(editTextEmail);
            String pass  = s(editTextPassword);

            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                Toast.makeText(this, "Enter email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Enforce 8-char minimum
            if (!AuthManager.isValidPassword(pass)) {
                editTextPassword.setError("Password must be at least " + AuthManager.MIN_PASSWORD_LENGTH + " characters");
                Toast.makeText(this, "Password must be at least " + AuthManager.MIN_PASSWORD_LENGTH + " characters", Toast.LENGTH_SHORT).show();
                return;
            }

            // Fake user id for local demo
            int userId = 1;
            String hash = sha256(pass);
            session.saveAccount(email, hash, userId);

            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
        });

        // Login
        buttonLogin.setOnClickListener(v -> {
            String email = s(editTextEmail);
            String pass  = s(editTextPassword);

            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                Toast.makeText(this, "Enter email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Optional: enforce same rule on login entry
            if (!AuthManager.isValidPassword(pass)) {
                editTextPassword.setError("Password must be at least " + AuthManager.MIN_PASSWORD_LENGTH + " characters");
                Toast.makeText(this, "Password must be at least " + AuthManager.MIN_PASSWORD_LENGTH + " characters", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!session.hasAccount()) {
                Toast.makeText(this, "No account found. Create one first.", Toast.LENGTH_SHORT).show();
                return;
            }

            String storedHash = session.getPasswordHash();
            if (sha256(pass).equals(storedHash)) {
                session.setLoggedIn(true);
                Toast.makeText(this, "Welcome!", Toast.LENGTH_SHORT).show();
                goToList();
            } else {
                Toast.makeText(this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void goToList() {
        startActivity(new Intent(this, VacationList.class));
        finish();
    }

    private static String s(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return input; // fallback (should not happen)
        }
    }
}
