package com.brandenvw.vacationmanager.UI;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.brandenvw.vacationmanager.R;
import com.google.android.material.appbar.MaterialToolbar;

public class ReportActivity extends AppCompatActivity {

    public static final String EXTRA_REPORT_CONTENT = "report_content";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back arrow
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Handle back arrow click
        toolbar.setNavigationOnClickListener(v -> {
            Intent intent = new Intent(ReportActivity.this, VacationList.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        // Report text
        TextView reportTextView = findViewById(R.id.tvReportContent);
        String report = getIntent().getStringExtra(EXTRA_REPORT_CONTENT);
        if (report != null) {
            reportTextView.setText(report);
        }
    }
}
