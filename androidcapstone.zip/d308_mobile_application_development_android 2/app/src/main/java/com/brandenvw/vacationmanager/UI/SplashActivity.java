package com.brandenvw.vacationmanager.UI;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.brandenvw.vacationmanager.util.SessionManager;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SessionManager session = new SessionManager(this);
        if (session.isLoggedIn()) {
            startActivity(new Intent(this, VacationList.class)); // your home screen
        } else {
            startActivity(new Intent(this, Login.class));
        }
        finish();
    }
}
