package com.brandenvw.vacationmanager.UI;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.brandenvw.vacationmanager.R;
import com.brandenvw.vacationmanager.entities.VacationWithExcursions;

import java.util.ArrayList;
import java.util.List;

public class VacationAdapter extends RecyclerView.Adapter<VacationAdapter.VacationViewHolder> {

    public interface OnVacationClick {
        void onVacationClick(int position);
    }

    private final Context context;
    private final OnVacationClick listener;
    private final List<VacationWithExcursions> items = new ArrayList<>();
    private final List<VacationWithExcursions> selected = new ArrayList<>();

    public VacationAdapter(Context context, OnVacationClick listener) {
        this.context = context;
        this.listener = listener;
    }

    public void setItems(List<VacationWithExcursions> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        selected.clear();
        notifyDataSetChanged();
    }

    public List<VacationWithExcursions> getSelected() {
        return selected;
    }

    @NonNull
    @Override
    public VacationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_vacation, parent, false);
        return new VacationViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VacationViewHolder holder, int position) {
        VacationWithExcursions vwe = items.get(position);

        if (vwe != null && vwe.vacation != null) {
            holder.tvTitle.setText(vwe.vacation.getTitle());
            holder.checkBox.setOnCheckedChangeListener(null);

            holder.checkBox.setChecked(selected.contains(vwe));

            holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    if (!selected.contains(vwe)) selected.add(vwe);
                } else {
                    selected.remove(vwe);
                }
            });

            holder.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onVacationClick(position);
            });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VacationViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        CheckBox checkBox;

        VacationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvVacationTitle);
            checkBox = itemView.findViewById(R.id.cbSelect);
        }
    }
}
