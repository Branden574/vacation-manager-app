package com.brandenvw.vacationmanager.UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.brandenvw.vacationmanager.R;
import com.brandenvw.vacationmanager.adapters.ExcursionAdapter;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.repositories.Repository;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class VacationDetails extends AppCompatActivity {

    private static final String TAG = "VacationDetails";

    private TextInputEditText etTitle;
    private AutoCompleteTextView etHotel;
    private TextInputEditText etPrice;
    private TextInputEditText etStart;
    private TextInputEditText etEnd;

    private MaterialButton btnSave;
    private MaterialButton btnAddExcursion;

    private RecyclerView rvExcursions;
    private TextView tvEmptyExcursions;
    private ExcursionAdapter excursionAdapter;

    private Repository repository;
    private int vacationId = -1;

    private static final String[] HOTELS = new String[]{
            "Hilton", "Hyatt", "Marriott", "Ritz-Carlton", "Holiday Inn", "Motel 6", "Airbnb"
    };

    private static final SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final NumberFormat CURRENCY = NumberFormat.getCurrencyInstance(Locale.US);

    private static final int REQ_POST_NOTIFICATIONS = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_details);

        repository = new Repository(getApplication());

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (toolbar != null) toolbar.setNavigationOnClickListener(v -> finish());

        etTitle = findViewById(R.id.etTitle);
        etHotel = findViewById(R.id.etHotel);
        etPrice = findViewById(R.id.etPrice);
        etStart = findViewById(R.id.etStart);
        etEnd   = findViewById(R.id.etEnd);

        btnSave = findViewById(R.id.btnSave);
        btnAddExcursion = findViewById(R.id.btnAddExcursion);

        // Excursions UI
        rvExcursions = findViewById(R.id.rvExcursions);
        tvEmptyExcursions = findViewById(R.id.tvEmptyExcursions);
        rvExcursions.setLayoutManager(new LinearLayoutManager(this));
        excursionAdapter = new ExcursionAdapter();
        rvExcursions.setAdapter(excursionAdapter);

        etHotel.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, HOTELS));

        etStart.setOnClickListener(v -> showDatePicker(etStart));
        etEnd.setOnClickListener(v -> showDatePicker(etEnd));

        // Load vacation if editing
        Intent i = getIntent();
        if (i != null) {
            vacationId = i.getIntExtra("vacationId", -1);
            if (vacationId != -1) {
                repository.getVacationById(vacationId).observe(this, v -> {
                    if (v == null) return;
                    etTitle.setText(nz(v.getTitle()));
                    etHotel.setText(nz(v.getHotel()), false);
                    etPrice.setText(String.valueOf(v.getPrice()));
                    etStart.setText(nz(v.getStartDate()));
                    etEnd.setText(nz(v.getEndDate()));
                });

                // Observe excursions for this vacation
                repository.getExcursionsForVacation(vacationId).observe(this, list -> {
                    excursionAdapter.setData(list);
                    boolean empty = (list == null || list.isEmpty());
                    tvEmptyExcursions.setVisibility(empty ? android.view.View.VISIBLE : android.view.View.GONE);
                    rvExcursions.setVisibility(empty ? android.view.View.GONE : android.view.View.VISIBLE);
                });
            } else {
                // New vacation: show empty state until saved
                tvEmptyExcursions.setVisibility(android.view.View.VISIBLE);
                rvExcursions.setVisibility(android.view.View.GONE);
            }
        }

        btnSave.setOnClickListener(v -> saveVacation());

        btnAddExcursion.setOnClickListener(v -> {
            if (vacationId == -1) {
                Toast.makeText(this, "Save the vacation first, then add excursions.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent it = new Intent(this, ExcursionDetails.class);
            it.putExtra("vacationId", vacationId);
            it.putExtra("excursionId", -1);
            startActivity(it);
        });
    }

    private void showDatePicker(TextInputEditText target) {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (DatePicker view, int year, int month, int dayOfMonth) -> {
                    String m = String.format(Locale.US, "%02d", month + 1);
                    String d = String.format(Locale.US, "%02d", dayOfMonth);
                    target.setText(year + "-" + m + "-" + d);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    private void saveVacation() {
        String title = txt(etTitle);
        String hotel = txt(etHotel);
        String priceStr = txt(etPrice);
        String start = txt(etStart);
        String end   = txt(etEnd);

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(start) || TextUtils.isEmpty(end)) {
            Toast.makeText(this, "Please complete Title, Start, and End.", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = 0.0;
        try { if (!TextUtils.isEmpty(priceStr)) price = Double.parseDouble(priceStr); }
        catch (NumberFormatException ignored) {}

        Vacation v = new Vacation(
                vacationId == -1 ? 0 : vacationId,
                title, hotel, price, start, end
        );

        if (vacationId == -1) {
            long newId = repository.insertVacationSync(v);
            if (newId > 0) {
                vacationId = (int) newId;
                Toast.makeText(this, "Vacation created", Toast.LENGTH_SHORT).show();
                // Start observing excursions now that we have an ID
                repository.getExcursionsForVacation(vacationId).observe(this, list -> {
                    excursionAdapter.setData(list);
                    boolean empty = (list == null || list.isEmpty());
                    tvEmptyExcursions.setVisibility(empty ? android.view.View.VISIBLE : android.view.View.GONE);
                    rvExcursions.setVisibility(empty ? android.view.View.GONE : android.view.View.VISIBLE);
                });
            } else {
                Toast.makeText(this, "Failed to save vacation.", Toast.LENGTH_SHORT).show();
            }
        } else {
            int rows = repository.updateVacationSync(v);
            if (rows > 0) {
                Toast.makeText(this, "Vacation updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No changes saved.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacation_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_share) {
            shareVacation();
            return true;
        }
        if (id == R.id.action_notify) {
            scheduleNotification();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void shareVacation() {
        String title = txt(etTitle);
        String hotel = txt(etHotel);
        String start = txt(etStart);
        String end   = txt(etEnd);

        double price = 0.0;
        try { String p = txt(etPrice); if (!p.isEmpty()) price = Double.parseDouble(p); } catch (NumberFormatException ignored) {}

        StringBuilder sb = new StringBuilder();
        sb.append("Vacation\n");
        sb.append("--------\n");
        sb.append("Title: ").append(title.isEmpty() ? "(none)" : title).append("\n");
        sb.append("Hotel: ").append(hotel.isEmpty() ? "(none)" : hotel).append("\n");
        sb.append("Dates: ").append(start.isEmpty() ? "(?)" : start)
                .append(" to ").append(end.isEmpty() ? "(?)" : end).append("\n");
        sb.append("Price: ").append(CURRENCY.format(price)).append("\n");

        if (vacationId != -1) {
            List<Excursion> exs = repository.getAssociatedExcursionsSync(vacationId);
            if (exs != null && !exs.isEmpty()) {
                sb.append("\nExcursions:\n");
                double extras = 0.0;
                for (Excursion e : exs) {
                    extras += e.getPrice();
                    sb.append(" • ").append(e.getTitle() == null ? "(no title)" : e.getTitle())
                            .append(" — ").append(CURRENCY.format(e.getPrice()));
                    if (e.getDate() != null && !e.getDate().isEmpty()) sb.append(" on ").append(e.getDate());
                    sb.append("\n");
                }
                sb.append("Excursions total: ").append(CURRENCY.format(extras)).append("\n");
                sb.append("Grand total: ").append(CURRENCY.format(price + extras)).append("\n");
            }
        }

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "Vacation Details");
        share.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(share, "Share via"));
    }

    private void scheduleNotification() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(
                        this, android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {

                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{ android.Manifest.permission.POST_NOTIFICATIONS },
                            REQ_POST_NOTIFICATIONS
                    );
                    Toast.makeText(this, "Please allow notifications and tap Notify again.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            String title = txt(etTitle);
            String start = txt(etStart);
            if (TextUtils.isEmpty(start)) {
                Toast.makeText(this, "Enter a Start date first (yyyy-MM-dd).", Toast.LENGTH_SHORT).show();
                return;
            }

            long when;
            try {
                when = DF.parse(start).getTime();
            } catch (ParseException pe) {
                Toast.makeText(this, "Invalid Start date. Use yyyy-MM-dd.", Toast.LENGTH_SHORT).show();
                return;
            }

            long now = System.currentTimeMillis();
            if (when <= now) {
                when = now + 10_000L;
                Toast.makeText(this, "Start is in the past. Scheduling test notification in ~10s.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Notification scheduled for " + start, Toast.LENGTH_SHORT).show();
            }

            Intent intent = new Intent(this, MyVacationReceiver.class);
            intent.putExtra("title", TextUtils.isEmpty(title) ? "Vacation starts!" : (title + " starts!"));
            intent.putExtra("message", "Your vacation begins on " + txt(etStart));
            int notificationId = (vacationId == -1 ? (int) (System.currentTimeMillis() & 0x7fffffff) : vacationId);
            intent.putExtra("notification_id", notificationId);

            PendingIntent pi = PendingIntent.getBroadcast(
                    this,
                    notificationId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) {
                Toast.makeText(this, "Alarm service unavailable.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean scheduled = false;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                    scheduled = true;
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                    scheduled = true;
                    try {
                        Intent settingsIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                        settingsIntent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(settingsIntent);
                    } catch (Exception ignored) {}
                    Toast.makeText(this, "Scheduled inexact alarm. You can enable exact alarms in settings.", Toast.LENGTH_LONG).show();
                }
            }

            if (!scheduled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "scheduleNotification failed", e);
            Toast.makeText(this, "Failed to schedule" + (e.getMessage() == null ? "" : (": " + e.getMessage())), Toast.LENGTH_LONG).show();
        }
    }

    private static String txt(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String txt(AutoCompleteTextView et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
