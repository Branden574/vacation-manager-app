package com.brandenvw.vacationmanager.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.brandenvw.vacationmanager.R;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.entities.VacationWithExcursions;
import com.brandenvw.vacationmanager.util.SessionManager;
import com.brandenvw.vacationmanager.viewmodel.VacationListViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class VacationList extends AppCompatActivity implements VacationAdapter.OnVacationClick {

    private VacationListViewModel viewModel;

    private RecyclerView rv;
    private View tvEmpty;
    private TextInputEditText etSearch;
    private FloatingActionButton fab;

    private VacationAdapter adapter;
    private final List<VacationWithExcursions> all = new ArrayList<>();
    private final List<VacationWithExcursions> shown = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_list);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (toolbar != null) {
            toolbar.setOnMenuItemClickListener(this::onToolbarItemClick);
        }

        rv = findViewById(R.id.rvVacations);
        tvEmpty = findViewById(R.id.tvEmpty);
        etSearch = findViewById(R.id.etSearch);
        fab = findViewById(R.id.fabAdd);

        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new VacationAdapter(this, this);
        rv.setAdapter(adapter);

        fab.setOnClickListener(v -> startActivity(new Intent(this, VacationDetails.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                applyFilter(s == null ? "" : s.toString());
                if (viewModel != null) viewModel.setSearch(s == null ? "" : s.toString());
            }
        });

        viewModel = new ViewModelProvider(this).get(VacationListViewModel.class);

        viewModel.getAllWithExcursions().observe(this, list -> {
            all.clear();
            if (list != null) all.addAll(list);
            applyFilter(etSearch.getText() == null ? "" : etSearch.getText().toString());
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacation_list, menu);
        return true;
    }

    private void applyFilter(String qRaw) {
        String q = qRaw.trim().toLowerCase();
        shown.clear();
        if (q.isEmpty()) {
            shown.addAll(all);
        } else {
            for (VacationWithExcursions vwe : all) {
                Vacation v = vwe == null ? null : vwe.vacation;
                String title = v != null && v.getTitle() != null ? v.getTitle().toLowerCase() : "";
                String hotel = v != null && v.getHotel() != null ? v.getHotel().toLowerCase() : "";
                if (title.contains(q) || hotel.contains(q)) shown.add(vwe);
            }
        }
        adapter.setItems(shown);
        toggleEmpty();
    }

    private void toggleEmpty() {
        boolean empty = shown.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        rv.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private boolean onToolbarItemClick(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_generate_report) {
            String report = viewModel.buildReportSync();
            Intent intent = new Intent(this, ReportActivity.class);
            intent.putExtra(ReportActivity.EXTRA_REPORT_CONTENT, report);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_sign_out) {
            SessionManager sm = new SessionManager(this);
            sm.setLoggedIn(false);
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        } else if (id == R.id.action_delete) {
            deleteSelectedVacations();
            return true;
        }
        return false;
    }

    private void deleteSelectedVacations() {
        List<VacationWithExcursions> selected = adapter.getSelected();
        if (selected.isEmpty()) return;

        for (VacationWithExcursions vwe : selected) {
            if (vwe != null && vwe.vacation != null) {
                viewModel.delete(vwe.vacation);
            }
        }
    }

    @Override
    public void onVacationClick(int position) {
        if (position < 0 || position >= shown.size()) return;
        VacationWithExcursions vwe = shown.get(position);
        if (vwe == null || vwe.vacation == null) return;
        Intent i = new Intent(this, VacationDetails.class);
        i.putExtra("vacationId", vwe.vacation.getVacationID());
        startActivity(i);
    }
}
