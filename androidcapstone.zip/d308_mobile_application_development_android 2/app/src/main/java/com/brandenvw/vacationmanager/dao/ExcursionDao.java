package com.brandenvw.vacationmanager.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.brandenvw.vacationmanager.entities.Excursion;

import java.util.List;

@Dao
public interface ExcursionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Excursion excursion);

    @Update
    int update(Excursion excursion);

    @Delete
    int delete(Excursion excursion);

    @Query("SELECT * FROM excursions ORDER BY excursionId ASC")
    LiveData<List<Excursion>> getAll();

    // NOTE: entity column is 'vacationId' and date column is 'date' in your model.
    @Query("SELECT * FROM excursions WHERE vacationId = :vacationId ORDER BY date ASC")
    LiveData<List<Excursion>> getForVacation(int vacationId);

    @Query("SELECT * FROM excursions WHERE vacationId = :vacationId ORDER BY date ASC")
    List<Excursion> getForVacationSync(int vacationId);

    @Query("SELECT * FROM excursions WHERE excursionId = :id")
    LiveData<Excursion> getById(int id);

    @Query("DELETE FROM excursions")
    void deleteAll();
}
