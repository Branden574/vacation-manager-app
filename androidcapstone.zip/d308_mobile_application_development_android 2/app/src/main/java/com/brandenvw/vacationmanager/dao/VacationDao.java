package com.brandenvw.vacationmanager.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.entities.VacationWithExcursions;

import java.util.List;

@Dao
public interface VacationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Vacation vacation);

    @Update
    int update(Vacation vacation);

    @Delete
    int delete(Vacation vacation);

    @Query("SELECT * FROM vacations ORDER BY vacationID ASC")
    LiveData<List<Vacation>> getAll();

    @Query("SELECT * FROM vacations WHERE vacationID = :id LIMIT 1")
    LiveData<Vacation> getById(int id);

    /* --- With Excursions (LiveData) --- */
    @Transaction
    @Query("SELECT * FROM vacations ORDER BY vacationID ASC")
    LiveData<List<VacationWithExcursions>> getAllWithExcursions();

    /* --- With Excursions (SYNC) --- */
    @Transaction
    @Query("SELECT * FROM vacations ORDER BY vacationID ASC")
    List<VacationWithExcursions> getAllWithExcursionsSync();
}
