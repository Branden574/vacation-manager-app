package com.brandenvw.vacationmanager.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.brandenvw.vacationmanager.dao.ExcursionDao;
import com.brandenvw.vacationmanager.dao.VacationDao;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;

@Database(
        entities = {Vacation.class, Excursion.class},
        version = 1,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract VacationDao vacationDao();
    public abstract ExcursionDao excursionDao();

    /** Singleton accessor your Repository expects. */
    public static AppDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "d308_room_db"
                            )
                            // For small/student projects it’s OK to allow main thread queries
                            // because you call a few “Sync” methods. For production, remove this
                            // and ensure all blocking calls run off main.
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
