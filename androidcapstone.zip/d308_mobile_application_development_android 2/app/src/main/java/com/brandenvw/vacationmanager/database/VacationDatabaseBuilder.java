package com.brandenvw.vacationmanager.database;

import android.content.Context;

import androidx.room.Room;

public final class VacationDatabaseBuilder {

    private static volatile AppDatabase INSTANCE;

    private VacationDatabaseBuilder() {}

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (VacationDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "d308-db"
                            )
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
