package com.brandenvw.vacationmanager.entities;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "excursions")
public class Excursion {

    @PrimaryKey(autoGenerate = true)
    private int excursionId;

    private String title;
    private double price;
    private int vacationId;
    private String date;
    private String notes;

    // Constructor Room uses
    public Excursion(int excursionId, String title, double price,
                     int vacationId, String date, String notes) {
        this.excursionId = excursionId;
        this.title = title;
        this.price = price;
        this.vacationId = vacationId;
        this.date = date;
        this.notes = notes;
    }

    // Convenience constructor for inserts
    @Ignore
    public Excursion(String title, double price,
                     int vacationId, String date, String notes) {
        this(0, title, price, vacationId, date, notes);
    }

    // Getters/setters
    public int getExcursionId() { return excursionId; }
    public void setExcursionId(int excursionId) { this.excursionId = excursionId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public int getVacationId() { return vacationId; }
    public void setVacationId(int vacationId) { this.vacationId = vacationId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    // ---- Alias getter for compatibility with ViewModel ----
    public String getExcursionName() { return title; }
}
