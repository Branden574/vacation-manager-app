package com.brandenvw.vacationmanager.entities;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "vacations")
public class Vacation {

    @PrimaryKey(autoGenerate = true)
    private int vacationID;

    private String title;     // e.g., "Hawaii Getaway"
    private String hotel;     // e.g., "Hilton Waikiki"
    private double price;
    private String startDate;
    private String endDate;

    // Room constructor (includes PK)
    public Vacation(int vacationID,
                    String title,
                    String hotel,
                    double price,
                    String startDate,
                    String endDate) {
        this.vacationID = vacationID;
        this.title = title;
        this.hotel = hotel;
        this.price = price;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Convenience constructor for inserts (no ID yet)
    @Ignore
    public Vacation(String title,
                    String hotel,
                    double price,
                    String startDate,
                    String endDate) {
        this.title = title;
        this.hotel = hotel;
        this.price = price;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // ---- Getters/Setters ----
    public int getVacationID() { return vacationID; }
    public void setVacationID(int vacationID) { this.vacationID = vacationID; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getHotel() { return hotel; }
    public void setHotel(String hotel) { this.hotel = hotel; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    // ---- Alias getters for compatibility with ViewModel ----
    public String getVacationName() { return title; }
    public String getDestination() { return hotel; }
}
