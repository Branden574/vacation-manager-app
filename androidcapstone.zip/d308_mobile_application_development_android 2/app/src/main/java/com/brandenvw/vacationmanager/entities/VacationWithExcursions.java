package com.brandenvw.vacationmanager.entities;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

public class VacationWithExcursions {
    @Embedded public Vacation vacation;

    @Relation(
            parentColumn = "vacationID",
            entityColumn = "vacationId"
    )
    public List<Excursion> excursions;
}
