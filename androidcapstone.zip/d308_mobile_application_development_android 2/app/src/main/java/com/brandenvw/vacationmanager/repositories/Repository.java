package com.brandenvw.vacationmanager.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.brandenvw.vacationmanager.dao.ExcursionDao;
import com.brandenvw.vacationmanager.dao.VacationDao;
import com.brandenvw.vacationmanager.database.AppDatabase;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.entities.VacationWithExcursions;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Repository {

    private final AppDatabase db;
    private final VacationDao vacationDao;
    private final ExcursionDao excursionDao;
    private final Executor io = Executors.newSingleThreadExecutor();

    public Repository(Application application) {
        db = AppDatabase.getDatabase(application);
        vacationDao = db.vacationDao();
        excursionDao = db.excursionDao();
    }

    /* ===================== VACATIONS ===================== */

    public LiveData<List<Vacation>> getAllVacations() {
        return vacationDao.getAll();
    }

    public LiveData<List<VacationWithExcursions>> getAllWithExcursions() {
        return vacationDao.getAllWithExcursions();
    }

    /** SYNC: used by report code in VacationListViewModel. */
    public List<VacationWithExcursions> getAllWithExcursionsSync() {
        return vacationDao.getAllWithExcursionsSync();
    }

    public LiveData<Vacation> getVacationById(int id) {
        return vacationDao.getById(id);
    }

    /** Async insert/update/delete for Vacation */
    public void insert(Vacation v) {
        io.execute(() -> vacationDao.insert(v));
    }

    public void update(Vacation v) {
        io.execute(() -> vacationDao.update(v));
    }

    public void delete(Vacation v) {
        io.execute(() -> vacationDao.delete(v));
    }

    /** Sync insert/update (used in VacationDetails) */
    public long insertVacationSync(Vacation v) {
        return vacationDao.insert(v);
    }

    public int updateVacationSync(Vacation v) {
        return vacationDao.update(v);
    }

    /* ===================== EXCURSIONS ===================== */

    /** LiveData list for a vacation (name your code first tried to use). */
    public LiveData<List<Excursion>> getExcursionsForVacation(int vacationId) {
        return excursionDao.getForVacation(vacationId);
    }

    /** Alias for other ViewModel that calls getAssociatedExcursions(vacationId). */
    public LiveData<List<Excursion>> getAssociatedExcursions(int vacationId) {
        return excursionDao.getForVacation(vacationId);
    }

    /** SYNC list (used in sharing summary, etc.) */
    public List<Excursion> getAssociatedExcursionsSync(int vacationId) {
        return excursionDao.getForVacationSync(vacationId);
    }

    public LiveData<Excursion> getExcursionById(int id) {
        return excursionDao.getById(id);
    }

    /** Async insert/update/delete for Excursion */
    public void insert(Excursion e) {
        io.execute(() -> excursionDao.insert(e));
    }

    public void update(Excursion e) {
        io.execute(() -> excursionDao.update(e));
    }

    public void delete(Excursion e) {
        io.execute(() -> excursionDao.delete(e));
    }
}
