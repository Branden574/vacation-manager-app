package com.brandenvw.vacationmanager.util;

import android.content.Context;

public class AuthManager {
    private static final String PREF = "auth_prefs";
    private static final String KEY_LOGGED_IN = "logged_in";

    // ✅ Centralized password rule
    public static final int MIN_PASSWORD_LENGTH = 8;

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= MIN_PASSWORD_LENGTH;
    }

    public static boolean isLoggedIn(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getBoolean(KEY_LOGGED_IN, false);
    }

    public static void signIn(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_LOGGED_IN, true).apply();
    }

    public static void signOut(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_LOGGED_IN, false).apply();
    }
}
