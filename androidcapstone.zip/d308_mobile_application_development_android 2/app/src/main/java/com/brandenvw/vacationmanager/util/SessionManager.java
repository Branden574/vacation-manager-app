package com.brandenvw.vacationmanager.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SessionManager {
    private static final String PREFS = "d308_session_prefs";

    private static final String KEY_LOGGED_IN = "logged_in";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASSWORD_HASH = "password_hash";
    private static final String KEY_USER_ID = "user_id";

    private final SharedPreferences sp;

    public SessionManager(Context ctx) {
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /* ---------------- Common session flags ---------------- */

    public void setLoggedIn(boolean loggedIn) {
        sp.edit().putBoolean(KEY_LOGGED_IN, loggedIn).apply();
    }

    public boolean isLoggedIn() {
        return sp.getBoolean(KEY_LOGGED_IN, false);
    }

    /* ---------------- Newer API (used by LoginActivity) ---------------- */

    /** Save account with a precomputed hash. */
    public void saveAccount(String email, String passwordHash, int userId) {
        sp.edit()
                .putString(KEY_EMAIL, email)
                .putString(KEY_PASSWORD_HASH, passwordHash)
                .putInt(KEY_USER_ID, userId)
                .apply();
    }

    public boolean hasAccount() {
        return sp.contains(KEY_EMAIL) && sp.contains(KEY_PASSWORD_HASH);
    }

    public String getPasswordHash() {
        return sp.getString(KEY_PASSWORD_HASH, "");
    }

    public String getEmail() {
        return sp.getString(KEY_EMAIL, "");
    }

    public int getUserId() {
        return sp.getInt(KEY_USER_ID, -1);
    }

    /* ---------------- Legacy API (used by Login.java) ---------------- */

    /** Legacy alias for hasAccount(). */
    public boolean hasSavedCredentials() {
        return hasAccount();
    }

    /**
     * Legacy save that takes a plain password.
     * Computes SHA-256 and stores it, plus userId/email.
     */
    public void saveCredentials(int userId, String email, String plainPassword) {
        String hash = sha256(plainPassword);
        saveAccount(email, hash, userId);
    }

    /**
     * Legacy verify that takes a plain password, compares to stored hash.
     * Returns true if credentials match; DOES NOT toggle logged-in flag.
     */
    public boolean verifyLogin(String email, String plainPassword) {
        if (!email.equals(getEmail())) return false;
        String stored = getPasswordHash();
        String attempt = sha256(plainPassword);
        return stored.equals(attempt);
    }

    /* ---------------- Utilities ---------------- */

    public void clear() {
        sp.edit().clear().apply();
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // Fallback: store plain (not ideal, but avoids crashes in unlikely cases)
            return input;
        }
    }
}
