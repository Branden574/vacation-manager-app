package com.brandenvw.vacationmanager.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.repositories.Repository;
import java.util.List;

public class ExcursionDetailsViewModel extends AndroidViewModel {
    private Repository repository;
    private LiveData<List<Vacation>> allVacations;

    public ExcursionDetailsViewModel(@NonNull Application application) {
        super(application);
        repository = new Repository(application);
        allVacations = repository.getAllVacations();
    }

    public LiveData<Excursion> getExcursionById(int excursionId) {
        return repository.getExcursionById(excursionId);
    }

    public LiveData<List<Vacation>> getAllVacations() {
        return allVacations;
    }

    public void insert(Excursion excursion) {
        repository.insert(excursion);
    }

    public void update(Excursion excursion) {
        repository.update(excursion);
    }

    public void delete(Excursion excursion) {
        repository.delete(excursion);
    }
}
