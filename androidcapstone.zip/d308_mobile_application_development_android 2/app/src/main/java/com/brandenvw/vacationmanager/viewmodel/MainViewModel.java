package com.brandenvw.vacationmanager.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.repositories.Repository;

public class MainViewModel extends AndroidViewModel {

    private final Repository repository;

    public MainViewModel(@NonNull Application application) {
        super(application);
        repository = new Repository(application);
    }

    public void insert(Vacation vacation) {
        repository.insert(vacation); // now calls Vacation overload
    }
}
