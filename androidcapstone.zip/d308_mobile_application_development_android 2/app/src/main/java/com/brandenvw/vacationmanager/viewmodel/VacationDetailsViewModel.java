package com.brandenvw.vacationmanager.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.repositories.Repository;

import java.util.List;

public class VacationDetailsViewModel extends AndroidViewModel {

    private final Repository repository;

    public VacationDetailsViewModel(@NonNull Application application) {
        super(application);
        repository = new Repository(application);
    }

    public LiveData<Vacation> getVacationById(int id) { return repository.getVacationById(id); }

    public void insert(Vacation v) { repository.insert(v); }
    public void update(Vacation v) { repository.update(v); }
    public void delete(Vacation v) { repository.delete(v); }

    public LiveData<List<Excursion>> getAssociatedExcursions(int vacationId) {
        return repository.getAssociatedExcursions(vacationId);
    }
}
