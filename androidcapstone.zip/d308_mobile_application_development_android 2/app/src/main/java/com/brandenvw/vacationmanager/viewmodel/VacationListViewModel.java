package com.brandenvw.vacationmanager.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.brandenvw.vacationmanager.entities.Excursion;
import com.brandenvw.vacationmanager.entities.Vacation;
import com.brandenvw.vacationmanager.entities.VacationWithExcursions;
import com.brandenvw.vacationmanager.repositories.Repository;

import java.util.ArrayList;
import java.util.List;

public class VacationListViewModel extends AndroidViewModel {

    private final Repository repo;

    // for search filtering
    private final MutableLiveData<String> searchQuery = new MutableLiveData<>("");

    public VacationListViewModel(@NonNull Application application) {
        super(application);
        repo = new Repository(application);
    }

    // --- basic vacations ---
    public LiveData<List<Vacation>> getAllVacations() {
        return repo.getAllVacations();
    }

    // --- vacations with excursions (with search support) ---
    public LiveData<List<VacationWithExcursions>> getAllWithExcursions() {
        return Transformations.switchMap(searchQuery, query ->
                Transformations.map(repo.getAllWithExcursions(), list -> {
                    if (query == null || query.isEmpty()) return list;
                    List<VacationWithExcursions> filtered = new ArrayList<>();
                    for (VacationWithExcursions vwe : list) {
                        if (vwe.vacation.getVacationName() != null &&
                                vwe.vacation.getVacationName().toLowerCase().contains(query.toLowerCase())) {
                            filtered.add(vwe);
                        }
                    }
                    return filtered;
                })
        );
    }

    // search setter
    public void setSearch(String query) {
        searchQuery.setValue(query);
    }

    // --- mutations ---
    public void insert(Vacation vacation) { repo.insert(vacation); }
    public void update(Vacation vacation) { repo.update(vacation); }
    public void delete(Vacation vacation) { repo.delete(vacation); }

    // --- reporting helper ---
    public String buildReportSync() {
        List<VacationWithExcursions> all = repo.getAllWithExcursionsSync();
        StringBuilder sb = new StringBuilder();
        for (VacationWithExcursions vwe : all) {
            sb.append("Vacation: ").append(vwe.vacation.getVacationName())
                    .append(" (").append(vwe.vacation.getDestination()).append(")\n");
            if (vwe.excursions != null && !vwe.excursions.isEmpty()) {
                for (Excursion e : vwe.excursions) {
                    sb.append("   - Excursion: ").append(e.getExcursionName())
                            .append(" on ").append(e.getDate()).append("\n");
                }
            } else {
                sb.append("   (No excursions)\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
