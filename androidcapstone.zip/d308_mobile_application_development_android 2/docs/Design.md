mkdir -p docs
cat > docs/Design.md <<'EOF'
# Design Document — Vacation Manager (Android)

**Author:** Branden Vincent (011601357)  
**Target:** Android 8.0+ (minSdk 26), targetSdk 34  
**Architecture:** MVVM + Repository + Room (SQLite)

## 1. Overview
The app manages **Vacations** and their **Excursions**. Users can create/read/update/delete both, search vacations, receive date notifications, and generate a timestamped report. Data is stored locally with Room.

## 2. Architecture (MVVM + Repository)
- **UI (Activities)**: `UI/` screens render state and forward user actions to ViewModels.
- **ViewModels**: `viewmodel/` expose `LiveData` and orchestrate tasks with the Repository.
- **Repository**: `repositories/Repository` encapsulates DAOs and background executors.
- **Persistence**: `database/VacationDatabaseBuilder` (Room), `dao/` (DAOs), `entities/` (models).

## 3. Class Diagram
```mermaid
classDiagram
direction LR

class Vacation {
  -int vacationID
  -String vacationName
  -double price
  -String hotel
  -String startVacationDate
  -String endVacationDate
  +getters/setters()
}

class Excursion {
  -int excursionID
  -String excursionName
  -double price
  -int vacationID
  -String excursionDate
  -String notes
  +getters/setters()
}

class vacationdao {
  +insert(Vacation): long
  +update(Vacation): void
  +delete(Vacation): void
  +getAllVacations(): LiveData<List<Vacation>>
  +getVacationById(int): LiveData<Vacation>
  +deleteAllVacations(): void
}

class excursiondao {
  +insert(Excursion): void
  +update(Excursion): void
  +delete(Excursion): void
  +getAllExcursions(): LiveData<List<Excursion>>
  +getAssociatedExcursions(int): LiveData<List<Excursion>>
  +getAssociatedExcursionsSync(int): List<Excursion>
  +getExcursionById(int): LiveData<Excursion>
  +deleteAllExcursions(): void
}

class Repository {
  -vacationdao vacationDAO
  -excursiondao excursionDAO
  -ExecutorService databaseWriteExecutor
  +getAllVacations(): LiveData<List<Vacation>>
  +getVacationById(int): LiveData<Vacation>
  +insert(Vacation): void
  +update(Vacation): void
  +delete(Vacation): void
  +getAllExcursions(): LiveData<List<Excursion>>
  +getAssociatedExcursions(int): LiveData<List<Excursion>>
  +getAssociatedExcursionsSync(int): List<Excursion>
  +insert(Excursion): void
  +update(Excursion): void
  +delete(Excursion): void
  +addSampleData(): void
  +clearAllData(): void
}

class VacationListViewModel {
  -Repository repository
  -LiveData<List<Vacation>> allVacations
  -MutableLiveData<List<Vacation>> filteredVacations
  +getFilteredVacations(): LiveData<List<Vacation>>
  +setSearchQuery(String): void
  +generateReportAsync(cb): void
}

class VacationDetailsViewModel {
  -Repository repository
  +getVacationById(int): LiveData<Vacation>
  +getAssociatedExcursions(int): LiveData<List<Excursion>>
  +insert/update/delete(Vacation|Excursion): void
}

class ExcursionAdapter
class VacationAdapter
class SessionManager
class VacationDatabaseBuilder

VacationDatabaseBuilder --> vacationdao
VacationDatabaseBuilder --> excursiondao
Repository --> vacationdao
Repository --> excursiondao
VacationListViewModel --> Repository
VacationDetailsViewModel --> Repository
ExcursionAdapter --> Excursion
VacationAdapter --> Vacation
SessionManager --> "SharedPreferences"
Excursion --> Vacation : "FK vacationID"
