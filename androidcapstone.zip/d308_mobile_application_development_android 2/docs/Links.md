# Links & Version — Vacation Manager (Android)

## Capstone Repository
- **URL:** https://gitlab.com/wgu-gitlab-environment/student-repos/bvinc38/d424-software-engineering-capstone.git
- **Primary branch for grading:** `app`
- **Alternate branch (if required by course):** `working`

### Quick branch links
- **app:** https://gitlab.com/wgu-gitlab-environment/student-repos/bvinc38/d424-software-engineering-capstone/-/tree/app
- **working:** https://gitlab.com/wgu-gitlab-environment/student-repos/bvinc38/d424-software-engineering-capstone/-/tree/working

---

## Version Included in This Submission
> Fill these with your exact tag and commit SHA at submission time.

- **Tag:** `v1.0-capstone`
- **Commit (short SHA):** `XXXXXXX`  
  *(Get it with `git rev-parse --short HEAD` after your final commit on `app`.)*

---

## Build Artifacts (if provided)
- **Signed APK:** `app/release/app-release.apk` (attach in submission or provide a share link)

---

## Hosted Web Link
- **Not applicable.** This is a native Android application (no hosted web frontend).
