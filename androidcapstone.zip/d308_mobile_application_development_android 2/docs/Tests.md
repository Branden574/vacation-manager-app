# Part D — Testing Documentation

**Project:** Vacation Manager (Android)  
**Author:** Branden Vincent (011601357)

---

## D.1 Test Plan (Unit/Instrumented)

### Scope
- Room **DAO CRUD** for `Vacation` and `Excursion`.
- Validation covered by UI logic (dates/required fields) – verified functionally.

### Environments
- **Device/Emulator:** Android 13+ recommended (minSdk 26)
- **Build Variant:** `debug`
- **Runner:** Android JUnit4 (instrumented)

### Tools
- JUnit4, AndroidX Test, Room (in-memory), LiveData await helper.

### Test Cases

**T1 — Vacation DAO: Insert & Query (LiveData)**  
Steps: insert N vacations → query `getAllVacations()`  
Expected: list size == N; fields match.

**T2 — Vacation DAO: Update**  
Steps: insert → update hotel/price → query by ID  
Expected: updated fields returned.

**T3 — Vacation DAO: Delete**  
Steps: insert → delete → query all  
Expected: deleted row absent.

**T4 — Excursion DAO: Insert associated to Vacation**  
Steps: insert vacation (id=V) → insert excursions with `vacationID=V` → query `getAssociatedExcursions(V)`  
Expected: all inserted excursions returned; `vacationID` matches.

**T5 — Excursion DAO: Update**  
Steps: update notes/price → query by ID  
Expected: updated fields returned.

**T6 — Excursion DAO: Delete & DeleteAll**  
Steps: insert many → delete one → assert size reduced → `deleteAllExcursions()` → assert empty  
Expected: behaves as described.

---

## D.2 Unit Test Scripts (Instrumented)
### Locations

- **Instrumented DAO tests (source)**
    - `app/src/androidTest/java/com/example/d308_mobile_application_development_android/dao/VacationDaoTest.java`
    - `app/src/androidTest/java/com/example/d308_mobile_application_development_android/dao/ExcursionDaoTest.java`
    - (helper) `app/src/androidTest/java/com/example/d308_mobile_application_development_android/LiveDataTestUtil.java`

- **How to run**
    - Android Studio → Project view → `app/src/androidTest/java/.../dao` → right-click → **Run 'All Tests'**.

- **Reports generated after a run**
    - HTML report: `app/build/reports/androidTests/connected/index.html`
    - Raw results: `app/build/outputs/androidTest-results/connected/`
    - Test APK (debug): `app/build/outputs/apk/androidTest/debug/`

- **Screenshots for submission**
    - Place in: `docs/tests/screenshots/`
    - Example files: `dao_vacation_crud_pass.png`, `dao_excursion_crud_pass.png`

