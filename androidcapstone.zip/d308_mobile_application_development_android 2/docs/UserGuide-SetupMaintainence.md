cat > docs/UserGuide-SetupMaintenance.md <<'EOF'
# User Guide — Setup & Maintenance (Developers)

## 1. Prerequisites
- Android Studio (latest), JDK 17+, Android SDK 26–34.
- Git access to the capstone repo.

## 2. Clone & Open
```bash
git clone https://gitlab.com/wgu-gitlab-environment/student-repos/bvinc38/d424-software-engineering-capstone.git
cd d424-software-engineering-capstone
git switch app
