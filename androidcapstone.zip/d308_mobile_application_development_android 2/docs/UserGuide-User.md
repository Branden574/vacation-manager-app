# User Guide — Vacation Manager (Android)

## What the app does
Plan vacations and manage linked excursions. Search trips, get date notifications, and generate a timestamped report.

## Getting started
1. **Install** the signed APK (Android 8.0+).
2. **Open** the app.
3. **Create account** (email + password) on first run, then **Sign in**.
    - Password is stored as a **hash**; you must use the same password to sign in later.
4. You’ll land on the **Vacation List** screen.

## Vacations
- **Add a vacation**
    1. Tap **➕**.
    2. Enter **Name**, **Hotel**, **Price**, **Start Date**, **End Date** (use date pickers).
    3. Tap **Save**.
    - The app validates required fields, price format, and that **End Date ≥ Start Date**.
- **Edit a vacation**
    - Tap a vacation in the list → update fields → **Save**.
- **Delete a vacation**
    - Open the vacation → menu (**⋮**) → **Delete** → confirm.
    - Deletion is **blocked** if excursions exist (you’ll see a message).
- **Search vacations**
    - Use the **search bar** at the top to filter the list live.

## Excursions
- **Add an excursion**
    1. Open a vacation.
    2. In the **Excursions** section, tap **➕**.
    3. Enter **Title**, **Price**, **Date**, and optional **Notes** → **Save**.
    - The **Excursion Date must be within the vacation’s date range** and properly formatted.
- **Edit/Delete an excursion**
    - Tap an excursion → edit fields and **Save**, or use **Delete** in the menu.

## Reports
- From the **Vacation List** menu (**⋮**) → **Generate Report**.
- The report includes a **title**, **timestamp**, and all vacations with their excursions (multi-row/column style).
- Opens in the **Report** screen to view/share.

## Notifications
- The app schedules **start** and **end** notifications for vacations (and excursions, if enabled in your build).
- Ensure **Notifications** are allowed for the app in system settings.

## Account
- **Sign out:** menu (**⋮**) → **Sign out**.
- Your session is cleared; you’ll need the same email + password to sign back in.

## Tips & troubleshooting
- **Dates**: Use `MM/dd/yy`; ensure End ≥ Start.
- **Can’t add excursion**: Check that the excursion’s date is inside the vacation’s date window.
- **No notifications**: Enable notifications for the app in the device settings.
- **Search shows nothing**: Clear the search field to see full list.
